<template>
  <div class="about">
    <h1>CMPE 496 Human Computer Interaction Project</h1>
    <ul>
      <li>This is an online shopping project with a little database with sqlite</li>
      <li>There will be 10 furnitures listed. The users will login with a popup first.</li>
      <li>Then they will select a furniture and pay with a credit card info.</li>
      <li>The system will be able to sort the products according to their popularity.</li>
      <li>There will be three types of credit card: Visa, MasterCard, Discover</li>
      <li>The default value will be None for the credit card type</li>
      <li>The users will also enter their email address when buying</li>
      <li>There will be input validation in the user interface</li>
      <li>As database mongodb is used, there are two proejcts running one in frontend other is backend</li>
      <li>Nodejs used for backend, Vue.js used for frontend</li>
    </ul>
  </div>
</template>
