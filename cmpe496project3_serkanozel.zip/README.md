# Cmpe 496 Project 1

- Serkan Özel 2015400123
- As database mongodb is used, there are two projects running one in frontend other is backend
- This is an online furniture shopping project
- There will be 10 furnitures listed. The users will login with a popup first.
- Then will select a credit card type pay with a credit card info and email.
- The furnitures are sorted according to how many they are bought.
- There are three types of credit card: Visa, MasterCard, Discover
- The default value is None for the credit card type
- There will be input validation in the user interface for example for date mm/yy
- Nodejs used for backend, Vue.js used for frontend
- Database is flushed if backend restarted

* To start project go to back folder and run "npm install" first to install dependencies then "npm start"
* Go to front folder and run "npm install" to install dependencies then "npm run serve"
